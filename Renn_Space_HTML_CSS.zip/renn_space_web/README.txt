RENN SPACE — HTML/CSS/JavaScript starter

FILES
- index.html: app UI and features
- assets/kawaii-bedroom.jpg: installed kawaii bedroom wallpaper
- manifest.json: PWA install metadata
- sw.js: offline cache when hosted on localhost/HTTPS

QUICK TEST
1. Extract the ZIP and keep the folder structure intact.
2. Open index.html in Chrome to test basic features. Some browsers restrict file access/audio when opened as file://; if something doesn't work, use a local web server or host it on HTTPS.
3. For installable PWA and offline cache, serve the folder from HTTPS or localhost, open it in Chrome, then menu (⋮) > Add to Home screen / Install app.

IMPORTANT
- Journal/tasks/theme are saved in localStorage on the same browser/device.
- Music selection uses browser file input and object URLs. Playlist file handles are not permanently saved after closing/reloading the browser; select the music files again if needed.
- Background playback while the app/browser is closed is NOT guaranteed. This web version has no native Android foreground media service.
- To produce an APK, wrap the web app using a trusted Android WebView wrapper or Capacitor project; APK packaging is not included in this ZIP.
- Keep assets/kawaii-bedroom.jpg next to index.html in the assets folder. Do not rename it unless you also change the CSS URL.
